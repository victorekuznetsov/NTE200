@echo off
chcp 65001 >nul
title Обновление дашборда

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0обновить.ps1"

if errorlevel 1 (
    echo.
    echo *** Ошибка при обновлении — см. сообщения выше ***
    pause
)

:: Обновление маркеров отказов (если Python доступен)
where py >nul 2>&1
if not errorlevel 1 (
    echo.
    echo [Обновление данных об отказах из Excel...]
    py "%~dp0update_fail.py"
)
pause

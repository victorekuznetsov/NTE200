﻿# обновить.ps1
# Полное обновление dashboard_final.html из Excel — без Python
# Совместимость: Windows PowerShell 5.1+
# Запуск: ПКМ -> Выполнить с помощью PowerShell

$sw = [System.Diagnostics.Stopwatch]::StartNew()
$HERE = Split-Path -Parent $MyInvocation.MyCommand.Path

$HTML_FILE = Join-Path $HERE 'dashboard_final.html'
$NORMS_CSV = Join-Path $HERE 'normy_statistika.csv'
$SHEET     = 'Анализы'
$HDR_ROW   = 2

# Ищем Excel или CSV рядом или в папке выше
$XLSM = $null
foreach ($p in @(
    (Join-Path $HERE (Split-Path $HERE -Leaf) + '.xlsm'),
    (Join-Path $HERE 'Свод_анализов_масла.xlsm'),
    (Join-Path (Split-Path $HERE -Parent) 'Свод_анализов_масла.xlsm'),
    (Join-Path $HERE 'Свод_анализов_масла.csv'),
    (Join-Path (Split-Path $HERE -Parent) 'Свод_анализов_масла.csv')
)) {
    if (Test-Path $p) { $XLSM = $p; break }
}

function Log($msg) {
    Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg)
}

Log '====================================================='
Log 'Обновление dashboard_final.html'
if (-not $XLSM) {
    Log 'Excel-файл не найден автоматически — открываем диалог выбора файла...'
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $fd = New-Object System.Windows.Forms.OpenFileDialog
        $fd.Title  = 'Укажите файл данных — Excel (*.xlsm) или CSV (*.csv)'
        $fd.Filter = 'Данные (*.xlsm;*.xlsx;*.csv)|*.xlsm;*.xlsx;*.csv|All Files (*.*)|*.*'
        $fd.InitialDirectory = $HERE
        if ($fd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $XLSM = $fd.FileName }
    } catch { Log "Диалог файла недоступен: $_" }
}
if (-not $XLSM) { Log 'ОШИБКА: файл данных не выбран.'; Read-Host; exit 1 }
if (-not (Test-Path $HTML_FILE)) { Log "ОШИБКА: $HTML_FILE не найден"; Read-Host; exit 1 }
Log "Данные: $XLSM"
Log "HTML  : $HTML_FILE"
Log '====================================================='

# ── C# для метрик (быстро) ─────────────────────────────────
Add-Type -Language CSharp -TypeDefinition @'
using System;
public static class Calc {
    static double N(double v, double p) {
        if (p <= 0 || double.IsNaN(p) || double.IsNaN(v)) return 0;
        return Math.Min(3.0, v / p);
    }
    public static double[] M(double Fe,  double Cu, double Cr, double Al,
                              double Ni,  double Pb, double Si, double Na, double W,
                              double OXI, double NIT,double TAN,double TBN,
                              double fp90Fe, double fp90Cu, double fp90Cr, double fp90Al,
                              double fp90Ni, double fp90Pb, double fp90Si, double fp90Na,
                              double fp90OXI, double fp90NIT, double fp90TAN, double fp10TBN) {
        double WI = N(Fe,fp90Fe)*0.35 + N(Cu,fp90Cu)*0.25 + N(Cr,fp90Cr)*0.10
                  + N(Al,fp90Al)*0.10 + N(Ni,fp90Ni)*0.05 + N(Pb,fp90Pb)*0.15;
        double w = (double.IsNaN(W)||W<0) ? 0 : W;
        double CI = N(Si,fp90Si)*0.50 + N(Na,fp90Na)*0.30 + Math.Min(3.0,w/0.1)*0.20;
        double ps = (double.IsNaN(fp10TBN)||fp10TBN<=0) ? 5 : fp10TBN;
        double nTBN = Math.Max(0, 1-(double.IsNaN(TBN)?0:TBN)/(ps*1.5));
        double DI = N(OXI,fp90OXI)*0.30+N(NIT,fp90NIT)*0.15+N(TAN,fp90TAN)*0.35+nTBN*0.20;
        double RS = WI*0.5 + CI*0.25 + DI*0.25;
        double FP = Math.Max(0, Math.Min(100, 100.0/(1+Math.Exp(-(RS-1)*2.5))));
        return new double[]{ Math.Round(WI,3),Math.Round(CI,3),Math.Round(DI,3),
                             Math.Round(RS,3),Math.Round(FP,1) };
    }
}
'@ -ErrorAction Stop

# ── Утилиты ────────────────────────────────────────────────
$INV = [System.Globalization.CultureInfo]::InvariantCulture
function GD($s) {
    if ($null -eq $s) { return [double]::NaN }
    $d = 0.0
    if ([double]::TryParse($s.ToString(), [System.Globalization.NumberStyles]::Any, $INV, [ref]$d)) { return $d }
    return [double]::NaN
}
function SF($v) { if ($null -eq $v) { '' } else { $v.ToString().Trim() } }
function JE($s) { '"' + $s.ToString().Replace('\','\\').Replace('"','\"') + '"' }
function JV($v) {
    if ($null -eq $v) { return 'null' }
    if ($v -is [bool]) { return if ($v) { 'true' } else { 'false' } }
    if ($v -is [int] -or $v -is [long]) { return $v.ToString() }
    if ($v -is [double] -or $v -is [float]) {
        if ([double]::IsNaN($v) -or [double]::IsInfinity($v)) { return 'null' }
        return $v.ToString($INV)
    }
    return JE $v
}
function JO([hashtable]$h) {
    $parts = foreach ($k in ($h.Keys | Sort-Object)) { (JE $k) + ':' + (JV $h[$k]) }
    '{' + ($parts -join ',') + '}'
}
function ParseCsvLine([string]$line, [char]$dlm) {
    $flds=[System.Collections.Generic.List[string]]::new(); $inQ=$false
    $cur=[System.Text.StringBuilder]::new()
    foreach ($ch in $line.ToCharArray()) {
        if ($ch -eq '"') { $inQ=-not $inQ }
        elseif ($ch -eq $dlm -and -not $inQ) { [void]$flds.Add($cur.ToString().Trim()); [void]$cur.Clear() }
        else { [void]$cur.Append($ch) }
    }
    [void]$flds.Add($cur.ToString().Trim())
    return $flds.ToArray()
}
function AddRowToList([hashtable]$row) {
    $nk2=(SF $row['МодельУзла'])+'|'+(SF $row['Узел'])
    $nm=if($normMap.ContainsKey($nk2)){$normMap[$nk2]}else{@{}}
    $vFe=GD(SF $row['Fe']); $vCu=GD(SF $row['Cu']); $vCr=GD(SF $row['Cr'])
    $vAl=GD(SF $row['Al']); $vNi=GD(SF $row['Ni']); $vPb=GD(SF $row['Pb'])
    $vSi=GD(SF $row['Si']); $vNa=GD(SF $row['Na']); $vW=GD(SF $row['W'])
    $vOXI=GD(SF $row['OXI']); $vNIT=GD(SF $row['NIT']); $vTAN=GD(SF $row['TAN']); $vTBN=GD(SF $row['TBN'])
    $pFe=GD(SF $nm['Fe_p90']); $pCu=GD(SF $nm['Cu_p90']); $pCr=GD(SF $nm['Cr_p90'])
    $pAl=GD(SF $nm['Al_p90']); $pNi=GD(SF $nm['Ni_p90']); $pPb=GD(SF $nm['Pb_p90'])
    $pSi=GD(SF $nm['Si_p90']); $pNa=GD(SF $nm['Na_p90'])
    $pOXI=GD(SF $nm['OXI_p90']); $pNIT=GD(SF $nm['NIT_p90']); $pTAN=GD(SF $nm['TAN_p90']); $pTBN=GD(SF $nm['TBN_p10'])
    $m=[Calc]::M($vFe,$vCu,$vCr,$vAl,$vNi,$vPb,$vSi,$vNa,$vW,$vOXI,$vNIT,$vTAN,$vTBN,
                 $pFe,$pCu,$pCr,$pAl,$pNi,$pPb,$pSi,$pNa,$pOXI,$pNIT,$pTAN,$pTBN)
    $row['WI']=$m[0]; $row['CI']=$m[1]; $row['DI']=$m[2]; $row['RS']=$m[3]; $row['FP']=$m[4]
    $wi2=0.0; foreach ($f2 in 'Fe','Cu','Cr','Al','Ni','Pb','Sn'){$d2=GD(SF $row[$f2]);if(-not[double]::IsNaN($d2)){$wi2+=$d2}}
    $ci2=0.0; foreach ($f2 in 'Si','Na','K'){$d2=GD(SF $row[$f2]);if(-not[double]::IsNaN($d2)){$ci2+=$d2}}
    $row['WearIdx']=[Math]::Round($wi2,1); $row['ContamIdx']=[Math]::Round($ci2,1)
    foreach ($nf in $NRMS){if($nm.ContainsKey($nf)-and $nm[$nf]){$row[$nf]=$nm[$nf]}}
    $rows.Add($row)
}

# ── Маппинг столбцов Excel ─────────────────────────────────
$CMAP = @{
    'УО'='УО'; 'Передел'='Передел'; 'Тип техники'='ТипТехники'; 'Марка'='Марка'; 'Гаражный №'='Гар'; 'Узел'='Узел'
    'Модель узла'='МодельУзла'; 'Дата отбора пробы'='Дата'; 'Заключение'='st'
    'Наработка узла на дату отбора пробы (моточасы)'='nh'
    'Наработка масла на дату отбора пробы (моточасы)'='oh'
    'Fe'='Fe';'Cu'='Cu';'Cr'='Cr';'Al'='Al';'Ni'='Ni';'Pb'='Pb';'Sn'='Sn';'Si'='Si'
    'Na'='Na';'K'='K';'Ca'='Ca';'Zn'='Zn';'P'='P';'Mg'='Mg';'B'='B'
    'Содержание воды (W), %'='W'; 'Содержание гликоля (A), %'='A'
    'Содержание топлива (F), %'='F'; 'Содержание сажи (ST), А/0,1мм'='Soot'
    'Вязкость при 100°С (V100), cSt (сантистокс)'='V100'
    'Вязкость при 40°С (V40), cSt (сантистокс)'='V40'
    'Индекс вязкости (VI)'='VI'
    'Кислотное число (TAN), мгКОН/см3'='TAN'
    'Щелочное число (TBN), мгКОН/см3'='TBN'
    'Окисление (OXI), А/0,1мм'='OXI'
    'Нитрование (NIT), А/0,1мм'='NIT'
    'Сульфатная зольность (SUL), А/0,1мм'='SUL'
}
$NFIELDS = 'Fe','Cu','Cr','Al','Ni','Pb','Sn','Si','Na','K','Ca','Zn','P','Mg','B',
           'W','A','F','Soot','V100','V40','VI','TAN','TBN','OXI','NIT','SUL'
$NRMS    = 'Fe_p90','Cu_p90','Cr_p90','Al_p90','Ni_p90','Pb_p90',
           'Si_p90','Na_p90','OXI_p90','NIT_p90','TAN_p90','TBN_p10','W_p75'

# ── Нормы из CSV ───────────────────────────────────────────
$normMap = @{}
if (Test-Path $NORMS_CSV) {
    $nl = [System.IO.File]::ReadAllLines($NORMS_CSV, [System.Text.Encoding]::UTF8)
    $nh = $nl[0] -split ','
    for ($i = 1; $i -lt $nl.Count; $i++) {
        $nc = $nl[$i] -split ','
        $nr = @{}
        for ($j = 0; $j -lt $nh.Count; $j++) {
            $nr[$nh[$j].Trim()] = if ($j -lt $nc.Count) { $nc[$j].Trim() } else { '' }
        }
        $nk = $nr['НормаКлюч']
        if ($nk) { $normMap[$nk] = $nr }
    }
    Log ("Нормы: {0} групп" -f $normMap.Count)
} else { Log 'normy_statistika.csv не найден — нормы не применяются' }

# ── Чтение данных (Excel или CSV) ──────────────────────────
$IsCSV = ($XLSM -match '\.csv$')
Log 'Вычисление метрик...'
$rows = New-Object 'System.Collections.Generic.List[hashtable]'

if ($IsCSV) {
    Log 'CSV-режим: читаем без Excel...'
    $csvLines = [System.IO.File]::ReadAllLines($XLSM, [System.Text.Encoding]::UTF8)
    if ($csvLines.Count -lt 2) {
        $csvLines = [System.IO.File]::ReadAllLines($XLSM, [System.Text.Encoding]::GetEncoding(1251))
    }
    # определяем разделитель
    $dlm = [char]','
    if ($csvLines.Count -gt 0 -and ($csvLines[0] -split ';').Count -gt ($csvLines[0] -split ',').Count) { $dlm = [char]';' }
    # ищем строку с заголовками (первые 5 строк)
    $hdrIdx = 0
    for ($i2 = 0; $i2 -lt [Math]::Min(5, $csvLines.Count); $i2++) {
        $tH = ParseCsvLine $csvLines[$i2] $dlm
        if (($tH | Where-Object { $CMAP.ContainsKey($_.Trim()) }).Count -ge 3) { $hdrIdx = $i2; break }
    }
    $csvHdrs = ParseCsvLine $csvLines[$hdrIdx] $dlm
    # строим cidx (0-based)
    $cidx = @{}; $datecol = -1
    for ($c = 0; $c -lt $csvHdrs.Count; $c++) {
        $h = $csvHdrs[$c].Trim()
        $s2 = if ($CMAP.ContainsKey($h)) { $CMAP[$h] } else { $h }
        if ($s2) { $cidx[$c] = $s2 }
        if ($s2 -eq 'Дата') { $datecol = $c }
    }
    Log ("  Строк данных: {0}, Колонок: {1}" -f ($csvLines.Count - $hdrIdx - 1), $csvHdrs.Count)
    $rNum = 0
    for ($ri = $hdrIdx + 1; $ri -lt $csvLines.Count; $ri++) {
        $csvLine2 = $csvLines[$ri]; if (-not $csvLine2.Trim()) { continue }
        $cells = ParseCsvLine $csvLine2 $dlm
        if (-not $cells[0]) { continue }
        $row = @{}
        for ($c = 0; $c -lt $cells.Count; $c++) { if ($cidx.ContainsKey($c)) { $row[$cidx[$c]] = $cells[$c] } }
        # дата: DD.MM.YYYY -> YYYY-MM-DD
        if ($datecol -ge 0 -and $datecol -lt $cells.Count) {
            $dStr = $cells[$datecol]
            if ($dStr -match '^(\d{2})\.(\d{2})\.(\d{4})$') { $row['Дата'] = "$($Matches[3])-$($Matches[2])-$($Matches[1])" }
        }
        AddRowToList $row
        $rNum++
        if ($rNum % 10000 -eq 0) { Log ("  ...$rNum строк [{0}]" -f $sw.Elapsed.ToString('mm\:ss')) }
    }
} else {
    # ── Excel через COM ──────────────────────────────────────
    Log 'Открываем Excel...'
    try { $xl = New-Object -ComObject Excel.Application }
    catch { Log 'ОШИБКА: Microsoft Excel не найден.'; Read-Host; exit 1 }
    $xl.Visible = $false; $xl.DisplayAlerts = $false; $xl.AskToUpdateLinks = $false
    $wb = $xl.Workbooks.Open($XLSM, 0, $true)
    $ws = $null
    foreach ($s in $wb.Sheets) { if ($s.Name -eq $SHEET) { $ws = $s; break } }
    if (-not $ws) { Log "Лист $SHEET не найден"; $wb.Close($false); $xl.Quit(); Read-Host; exit 1 }
    $used = $ws.UsedRange; $nR = $used.Rows.Count; $nC = $used.Columns.Count
    Log ("  Строк: {0}, Колонок: {1}" -f $nR, $nC)
    Log 'Считываем данные...'
    $XV = $used.Value2
    $wb.Close($false); $xl.Quit()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null
    Log ("  Excel закрыт [{0}]" -f $sw.Elapsed.ToString('mm\:ss'))
    # Индекс столбцов
    $cidx = @{}; $datecol = 0
    for ($c = 1; $c -le $nC; $c++) {
        $h = if ($XV[$HDR_ROW,$c]) { $XV[$HDR_ROW,$c].ToString().Trim() } else { '' }
        $s2 = if ($CMAP.ContainsKey($h)) { $CMAP[$h] } else { $h }
        if ($s2) { $cidx[$c] = $s2 }
        if ($s2 -eq 'Дата') { $datecol = $c }
    }
    for ($r = $HDR_ROW + 1; $r -le $nR; $r++) {
        $f0 = $XV[$r,1]
        if ($null -eq $f0 -or $f0.ToString().Trim() -eq '') { continue }
        $row = @{}
        foreach ($kv in $cidx.GetEnumerator()) {
            $cv = $XV[$r,$kv.Key]
            $row[$kv.Value] = if ($null -eq $cv) { '' } else { $cv.ToString().Trim() }
        }
        if ($datecol -gt 0) {
            $dv2 = $XV[$r,$datecol]
            if ($dv2 -is [double] -and $dv2 -gt 1 -and $dv2 -lt 60000) {
                try { $row['Дата'] = [DateTime]::FromOADate($dv2).ToString('yyyy-MM-dd') } catch {}
            }
        }
        AddRowToList $row
        if ($r % 10000 -eq 0) { Log ("  ...{0}/{1} [{2}]" -f $r,$nR,$sw.Elapsed.ToString('mm\:ss')) }
    }
}
Log ("  Готово: {0} строк [{1}]" -f $rows.Count, $sw.Elapsed.ToString('mm\:ss'))

# ── Fleet norm fallback: P90 по ТипТехники+Узел ────────────
Log 'Fleet norm fallback...'
$fleetGroups = @{}
foreach ($row in $rows) {
    $tip = SF $row['ТипТехники']
    if (-not $tip) { continue }
    $fk = $tip + '|' + (SF $row['Узел'])
    if (-not $fleetGroups[$fk]) { $fleetGroups[$fk] = [System.Collections.Generic.List[hashtable]]::new() }
    $fleetGroups[$fk].Add($row)
}
$fleetNormMap = @{}
$flMetals = 'Fe','Cu','Cr','Al','Ni','Pb','Si','Na'
foreach ($fk in $fleetGroups.Keys) {
    $grp = $fleetGroups[$fk]
    if ($grp.Count -lt 10) { continue }
    $nm2 = @{}
    foreach ($metal in $flMetals) {
        $arr3 = @($grp | ForEach-Object { GD (SF $_[$metal]) } | Where-Object { -not [double]::IsNaN($_) } | Sort-Object)
        if ($arr3.Count -ge 10) { $nm2[$metal+'_p90'] = $arr3[[int]($arr3.Count*0.90)] }
    }
    foreach ($tp in @(@('OXI','OXI_p90',0.90),@('TAN','TAN_p90',0.90),@('TBN','TBN_p10',0.10))) {
        $arr3 = @($grp | ForEach-Object { GD (SF $_[$tp[0]]) } | Where-Object { -not [double]::IsNaN($_) } | Sort-Object)
        if ($arr3.Count -ge 10) { $nm2[$tp[1]] = $arr3[[int]($arr3.Count*[double]$tp[2])] }
    }
    if ($nm2.Count -gt 0) { $fleetNormMap[$fk] = $nm2 }
}
Log ("  Fleet групп: {0}" -f $fleetNormMap.Count)
$flFilled = 0
foreach ($row in $rows) {
    $nkChk = (SF $row['МодельУзла']) + '|' + (SF $row['Узел'])
    if ($normMap.ContainsKey($nkChk)) { continue }
    $tip = SF $row['ТипТехники']
    $fk = $tip + '|' + (SF $row['Узел'])
    if (-not $fleetNormMap.ContainsKey($fk)) { continue }
    $nm2 = $fleetNormMap[$fk]
    $vFe=GD(SF $row['Fe']); $vCu=GD(SF $row['Cu']); $vCr=GD(SF $row['Cr'])
    $vAl=GD(SF $row['Al']); $vNi=GD(SF $row['Ni']); $vPb=GD(SF $row['Pb'])
    $vSi=GD(SF $row['Si']); $vNa=GD(SF $row['Na']); $vW=GD(SF $row['W'])
    $vOXI=GD(SF $row['OXI']); $vNIT=GD(SF $row['NIT']); $vTAN=GD(SF $row['TAN']); $vTBN=GD(SF $row['TBN'])
    $pFe=GD($nm2['Fe_p90']); $pCu=GD($nm2['Cu_p90']); $pCr=GD($nm2['Cr_p90'])
    $pAl=GD($nm2['Al_p90']); $pNi=GD($nm2['Ni_p90']); $pPb=GD($nm2['Pb_p90'])
    $pSi=GD($nm2['Si_p90']); $pNa=GD($nm2['Na_p90'])
    $pOXI=GD($nm2['OXI_p90']); $pNIT=[double]::NaN; $pTAN=GD($nm2['TAN_p90']); $pTBN=GD($nm2['TBN_p10'])
    $m=[Calc]::M($vFe,$vCu,$vCr,$vAl,$vNi,$vPb,$vSi,$vNa,$vW,$vOXI,$vNIT,$vTAN,$vTBN,
                 $pFe,$pCu,$pCr,$pAl,$pNi,$pPb,$pSi,$pNa,$pOXI,$pNIT,$pTAN,$pTBN)
    $row['WI']=$m[0]; $row['CI']=$m[1]; $row['DI']=$m[2]; $row['RS']=$m[3]; $row['FP']=$m[4]
    foreach ($nf in $NRMS) {
        $nfv = $nm2[$nf]
        if ($null -ne $nfv) { $row[$nf] = $nfv.ToString([System.Globalization.CultureInfo]::InvariantCulture) }
    }
    $flFilled++
}
Log ("  Fleet нормы: заполнено {0} строк" -f $flFilled)

# ── Дельты / FeR / Rolling ──────────────────────────────────
Log 'Дельты...'
$sortedRows = $rows | Sort-Object { SF $_['Гар'] }, { SF $_['Узел'] }, { SF $_['Дата'] }
$prevRow = @{}
$feHist  = @{}   # последние 3 и 5 значений Fe на Гар+Узел
foreach ($row in $sortedRows) {
    $k = (SF $row['Гар']) + '|' + (SF $row['Узел'])
    $p = $prevRow[$k]
    if ($p) {
        $dFe2=GD(SF $row['Fe']); $pFe2=GD(SF $p['Fe'])
        $dCu2=GD(SF $row['Cu']); $pCu2=GD(SF $p['Cu'])
        $dSi2=GD(SF $row['Si']); $pSi2=GD(SF $p['Si'])
        $dnh2=GD(SF $row['nh']); $pnh2=GD(SF $p['nh'])
        if (-not [double]::IsNaN($dFe2) -and -not [double]::IsNaN($pFe2)) { $row['dFe']=[Math]::Round($dFe2-$pFe2,1) }
        if (-not [double]::IsNaN($dCu2) -and -not [double]::IsNaN($pCu2)) { $row['dCu']=[Math]::Round($dCu2-$pCu2,1) }
        if (-not [double]::IsNaN($dSi2) -and -not [double]::IsNaN($pSi2)) { $row['dSi']=[Math]::Round($dSi2-$pSi2,1) }
        if (-not [double]::IsNaN($dnh2) -and -not [double]::IsNaN($pnh2)) {
            $dnh3=$dnh2-$pnh2
            if ($dnh3 -gt 0 -and -not [double]::IsNaN($dFe2) -and -not [double]::IsNaN($pFe2)) {
                $row['FeR']=[Math]::Round(($dFe2-$pFe2)/$dnh3*1000,1)
            }
        }
    }
    # Rolling Fe: среднее за 3 / макс за 5
    $feV = GD(SF $row['Fe'])
    if (-not [double]::IsNaN($feV)) {
        if (-not $feHist[$k]) { $feHist[$k] = [System.Collections.Generic.List[double]]::new() }
        $feHist[$k].Add($feV)
        $h = $feHist[$k]
        $h3 = [Math]::Max(0, $h.Count - 3)
        $h5 = [Math]::Max(0, $h.Count - 5)
        $row['Fr3']  = [Math]::Round(($h[$h3..($h.Count-1)] | Measure-Object -Average).Average, 1)
        $row['Fr5m'] = ($h[$h5..($h.Count-1)] | Measure-Object -Maximum).Maximum
    }
    $prevRow[$k]=$row
}
$rows = $sortedRows

# ── Построение DB ──────────────────────────────────────────
Log 'Построение DB...'
$DB = @{}
foreach ($row in $rows) {
    $br = (SF $row['Марка']); if (-not $br) { $br='Unknown' }
    $gr = (SF $row['Гар']);   if (-not $gr) { $gr='0' }
    $nd = (SF $row['Узел']);  if (-not $nd) { $nd='Main' }
    $uo = (SF $row['УО'])
    $peredel = (SF $row['Передел'])
    if (-not $peredel) {
        $tip = (SF $row['ТипТехники'])
        $ZIF = @('Декантер','Дробилка','Бутобой','Компрессорная установка','Конвейер','Мельница','Насос','Питатель','Сгуститель')
        $GTK = @('Бульдозер','Грейдер','Щебнеразбрасыватель','Дробильная установка','Каток грунтовый','Мобильный грохот','Погрузчик','Самосвал','Станок буровой','Трубоукладчик','Тягач-буксировщик','Экскаватор')
        if ($ZIF -contains $tip) { $peredel='ЗИФ' }
        elseif ($GTK -contains $tip) { $peredel='ГТК' }
        elseif ($tip) { $peredel='Прочее' }
    }
    $dt = (SF $row['Дата']); if (-not $dt -or $dt -match '^(nan|NaT|None)$') { $dt='—' }
    $st = (SF $row['st']);   if ($st -match '^(nan|None)$') { $st='' }

    if (-not $DB[$br]) { $DB[$br]=@{} }
    if (-not $DB[$br][$gr]) { $DB[$br][$gr]=@{ uo=$uo; peredel=$peredel; nodes=@{} } }
    if (-not $DB[$br][$gr].nodes[$nd]) { $DB[$br][$gr].nodes[$nd]=New-Object 'System.Collections.Generic.List[hashtable]' }

    $probe=@{dt=$dt}
    foreach ($f in $NFIELDS) { $d=GD(SF $row[$f]); if (-not [double]::IsNaN($d) -and $d -ne 0.0) { $probe[$f]=[Math]::Round($d,2) } }
    foreach ($f in 'nh','oh') { $d=GD(SF $row[$f]); if (-not [double]::IsNaN($d) -and $d -ne 0.0) { $probe[$f]=[int]$d } }
    foreach ($f in 'WI','CI','DI','RS','FP','WearIdx','ContamIdx','dFe','dCu','dSi','FeR','Fr3','Fr5m') {
        if ($row.ContainsKey($f)) { $probe[$f]=$row[$f] }
    }
    if ($st) { $probe['st']=$st }
    $DB[$br][$gr].nodes[$nd].Add($probe)
}
$nBr=0; $nMch=0; $nPr=0
foreach ($b in $DB.Values) { $nBr++; foreach ($g in $b.Values) { $nMch++; foreach ($n3 in $g.nodes.Values) { $nPr+=$n3.Count } } }
Log ("  Марок: {0}, Машин: {1}, Проб: {2}" -f $nBr,$nMch,$nPr)

# ── JSON ──────────────────────────────────────────────────
Log 'Сериализация JSON...'
$jsb = New-Object System.Text.StringBuilder 30000000
[void]$jsb.Append('{')
$bi2=0
foreach ($brand2 in ($DB.Keys | Sort-Object)) {
    if ($bi2++ -gt 0) { [void]$jsb.Append(',') }
    [void]$jsb.Append((JE $brand2)); [void]$jsb.Append(':{')
    $gi2=0
    foreach ($gar2 in ($DB[$brand2].Keys | Sort-Object)) {
        if ($gi2++ -gt 0) { [void]$jsb.Append(',') }
        [void]$jsb.Append((JE $gar2)); [void]$jsb.Append(':{"uo":')
        [void]$jsb.Append((JV $DB[$brand2][$gar2].uo)); [void]$jsb.Append(',"peredel":')
        [void]$jsb.Append((JV $DB[$brand2][$gar2].peredel)); [void]$jsb.Append(',"nodes":{')
        $ni2=0
        foreach ($nd2 in ($DB[$brand2][$gar2].nodes.Keys | Sort-Object)) {
            if ($ni2++ -gt 0) { [void]$jsb.Append(',') }
            [void]$jsb.Append((JE $nd2)); [void]$jsb.Append(':[')
            $pi2=0
            foreach ($pb in $DB[$brand2][$gar2].nodes[$nd2]) {
                if ($pi2++ -gt 0) { [void]$jsb.Append(',') }
                [void]$jsb.Append('{')
                $fi2=0
                foreach ($kv2 in ($pb.GetEnumerator() | Sort-Object Key)) {
                    if ($fi2++ -gt 0) { [void]$jsb.Append(',') }
                    [void]$jsb.Append((JE $kv2.Key)); [void]$jsb.Append(':'); [void]$jsb.Append((JV $kv2.Value))
                }
                [void]$jsb.Append('}')
            }
            [void]$jsb.Append(']')
        }
        [void]$jsb.Append('}}')
    }
    [void]$jsb.Append('}')
}
[void]$jsb.Append('}')
$jsonStr = $jsb.ToString()
Log ("  JSON: {0:N0} байт [{1}]" -f $jsonStr.Length, $sw.Elapsed.ToString('mm\:ss'))

# GZip + Base64
$jb = [System.Text.Encoding]::UTF8.GetBytes($jsonStr)
$ms = New-Object System.IO.MemoryStream
$gz = New-Object System.IO.Compression.GZipStream($ms,[System.IO.Compression.CompressionLevel]::Optimal)
$gz.Write($jb,0,$jb.Length); $gz.Close()
$b64str = [Convert]::ToBase64String($ms.ToArray())
Log ("  Сжато: {0:N0} -> base64: {1:N0}" -f $ms.Length, $b64str.Length)

# ── PRED_DATA ──────────────────────────────────────────────
Log 'PRED_DATA...'
$pc2 = 'V100','V40','TAN','FP','Si','OXI','Fe','TBN','WearIdx','Al','Pb','Na','Cu','Cr','Ni'
$fp90 = @{}
foreach ($col2 in $pc2) {
    $arr2 = @($rows | ForEach-Object { GD (SF $_[$col2]) } | Where-Object { -not [double]::IsNaN($_) } | Sort-Object)
    if ($arr2.Count -gt 0) { $fp90[$col2]=[Math]::Round($arr2[[int]($arr2.Count*0.9)],2) }
}

$latR=@{}; $grpR=@{}
foreach ($row in $rows) {
    $k2=(SF $row['Гар']) + '|' + (SF $row['Узел'])
    if (-not $grpR[$k2]) { $grpR[$k2]=@() }
    $grpR[$k2]+=$row
    $cur2=$latR[$k2]
    if (-not $cur2 -or (SF $row['Дата']) -gt (SF $cur2['Дата'])) { $latR[$k2]=$row }
}

$fpA=@($latR.Values | ForEach-Object { GD (SF $_['FP']) })
$flS=@{
    normal   = @($fpA | Where-Object { $_ -lt 10 }).Count
    warning  = @($fpA | Where-Object { $_ -ge 10 -and $_ -lt 30 }).Count
    critical = @($fpA | Where-Object { $_ -ge 30 }).Count
    total    = $fpA.Count
}

$rList=New-Object 'System.Collections.Generic.List[hashtable]'
foreach ($kv3 in $latR.GetEnumerator()) {
    $last2=$kv3.Value
    $grp3=@($grpR[$kv3.Key] | Sort-Object { SF $_['Дата'] })
    $n3=$grp3.Count
    $br3=(SF $last2['Марка']); if (-not $br3) { $br3='Unknown' }
    $gr3=(SF $last2['Гар']);   if (-not $gr3) { $gr3='0' }
    $nd3=(SF $last2['Узел']);  if (-not $nd3) { $nd3='Main' }
    $uo3=(SF $last2['УО']); $dt3=(SF $last2['Дата'])
    $peredel3=(SF $last2['Передел'])
    if (-not $peredel3) {
        $tip3=(SF $last2['ТипТехники'])
        if (@('Декантер','Дробилка','Бутобой','Компрессорная установка','Конвейер','Мельница','Насос','Питатель','Сгуститель') -contains $tip3) { $peredel3='ЗИФ' }
        elseif (@('Бульдозер','Грейдер','Щебнеразбрасыватель','Дробильная установка','Каток грунтовый','Мобильный грохот','Погрузчик','Самосвал','Станок буровой','Трубоукладчик','Тягач-буксировщик','Экскаватор') -contains $tip3) { $peredel3='ГТК' }
        elseif ($tip3) { $peredel3='Прочее' }
    }
    $feV3=GD(SF $last2['Fe']); $cuV3=GD(SF $last2['Cu']); $siV3=GD(SF $last2['Si'])
    $fpV3=GD(SF $last2['FP']); if ([double]::IsNaN($fpV3)) { $fpV3=0.0 }
    $prv3=if ($n3 -ge 2) { $grp3[$n3-2] } else { $null }
    $feS3=0.0; if ($prv3 -and -not [double]::IsNaN($feV3)) { $feS3=[Math]::Round($feV3-(GD(SF $prv3['Fe'])),1) }
    $cuS3=0.0; if ($prv3 -and -not [double]::IsNaN($cuV3)) { $cuS3=[Math]::Round($cuV3-(GD(SF $prv3['Cu'])),1) }

    $bR3=0.0; $drv=''
    foreach ($mt in @('Fe','Cu','Si','OXI','TAN','Na')) {
        $mv3=GD(SF $last2[$mt]); $pv3=GD(SF $last2[($mt+'_p90')])
        if (-not [double]::IsNaN($mv3) -and $pv3 -gt 0) {
            $rat=$mv3/$pv3
            if ($rat -gt $bR3) { $bR3=$rat; $drv="{0}={1}ppm ({2}x p90)" -f $mt,[int]$mv3,[Math]::Round($rat,1) }
        }
    }
    $risk3=[Math]::Round([Math]::Min(100.0,[Math]::Max($bR3*10.0,$fpV3)),1)
    if ($risk3 -lt 5.0) { continue }
    $rList.Add(@{
        brand=$br3; mach=$gr3; node=$nd3; uo=$uo3; peredel=$peredel3
        fe=if([double]::IsNaN($feV3)){$null}else{$feV3}
        cu=if([double]::IsNaN($cuV3)){$null}else{$cuV3}
        si=if([double]::IsNaN($siV3)){$null}else{$siV3}
        fe_s=$feS3; cu_s=$cuS3; risk=$risk3; fp=$fpV3; n=$n3; dt=$dt3; driver=$drv
    })
}
$rArr=@($rList | Sort-Object { -$_.risk } | Select-Object -First 100)
Log ("  Риск-записей: {0}" -f $rArr.Count)

$fmodes=@{}
foreach ($mt in @('Fe','Cu','Si')) {
    $pk3=$mt+'_p90'
    $lbl=@{Fe='High Fe (Износ)';Cu='High Cu (Подшипники)';Si='Si (Загрязнение)'}[$mt]
    $fmodes[$lbl]=@($rows | Where-Object { $mv4=GD(SF $_[$mt]);$pv4=GD(SF $_[$pk3]); -not [double]::IsNaN($mv4) -and $pv4 -gt 0 -and $mv4 -gt $pv4 }).Count
}
$fmodes['Риск FP>30%']    = @($rows | Where-Object { (GD(SF $_['FP'])) -ge 30 }).Count
$fmodes['Критич. Fe>300'] = @($rows | Where-Object { (GD(SF $_['Fe'])) -gt 300 }).Count

function JRec2([hashtable]$rec) {
    $parts2=foreach ($k3 in $rec.Keys) { if ($null -ne $rec[$k3]) { (JE $k3)+':'+(JV $rec[$k3]) } }
    '{' + ($parts2 -join ',') + '}'
}

$predJSON = '{"risk_records":[' + (($rArr | ForEach-Object { JRec2 $_ }) -join ',') + ']' +
            ',"fleet_stats":'   + (JO $flS) +
            ',"failure_modes":' + (JO $fmodes) +
            ',"fleet_p90":'     + (JO $fp90) + '}'

# ── Обновление HTML ────────────────────────────────────────
Log 'Обновление HTML...'
$html = [System.IO.File]::ReadAllText($HTML_FILE, [System.Text.Encoding]::UTF8)

# Построчная замена DATA_B64, PRED_DATA и даты
$hlines = $html -split "`n"
$newB64Line = 'const DATA_B64="' + $b64str + '"'
$ts = (Get-Date).ToString('dd.MM.yyyy')

for ($i = 0; $i -lt $hlines.Count; $i++) {
    $line = $hlines[$i]
    if ($line -match 'const DATA_B64=') {
        $hlines[$i] = $newB64Line
    } elseif ($line.TrimStart().StartsWith('const PRED_DATA') -and $line -match '=') {
        $hlines[$i] = 'const PRED_DATA=' + $predJSON + ';'
    } elseif ($line -match 'офлайн') {
        $hlines[$i] = [System.Text.RegularExpressions.Regex]::Replace($line, '\d{2}\.\d{2}\.\d{4}', $ts)
    }
}
$html = $hlines -join "`n"
[System.IO.File]::WriteAllText($HTML_FILE, $html, [System.Text.Encoding]::UTF8)
$sw.Stop()
Log ("Сохранено: {0:N0} байт" -f $html.Length)
Log '====================================================='
Log ("ГОТОВО! Время: {0}" -f $sw.Elapsed.ToString('mm\:ss'))
Log '====================================================='

Start-Process $HTML_FILE
Read-Host 'Нажмите Enter для закрытия'

# -*- coding: utf-8 -*-
"""
update_fail.py — обновить FAIL_DATA в dashboard_final.html
из Сводный_анализ_неисправностей.xlsx

Запуск: py update_fail.py
Можно добавить в обновить.bat
"""
import json, openpyxl, sys
from datetime import datetime
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

HERE = Path(__file__).parent
HTML  = HERE / "dashboard_final.html"
HTML2 = HERE / "для_другого_ПК" / "dashboard_final.html"  # копия для архива

# ── Найти Excel автоматически ───────────────────────────────
def find_excel() -> Path:
    candidates = [
        HERE / "для_другого_ПК" / "Сводный_анализ_неисправностей.xlsx",
        HERE / "fail_data.xlsx",
        *HERE.glob("для_другого_ПК*/*исправностей.xlsx"),
        *HERE.glob("*исправностей.xlsx"),
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("Файл Сводный_анализ_неисправностей.xlsx не найден.")

# ── Строим FAIL_DATA ────────────────────────────────────────
def build_fail_data(path: Path) -> dict:
    print(f"Читаем: {path.name}")
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()

    def norm_gar(raw) -> str:
        if raw is None:
            return ''
        if isinstance(raw, float):
            return str(int(raw)) if raw == int(raw) else str(raw)
        s = str(raw).strip()
        if s.endswith('.0') and s[:-2].isdigit():
            return s[:-2]
        return s

    def norm_dt(raw) -> str:
        if isinstance(raw, datetime):
            return raw.strftime('%Y-%m-%d')
        s = str(raw or '').strip()
        parts = s.split('.')
        if len(parts) == 3 and len(parts[2]) == 4:
            return f'{parts[2]}-{parts[1]}-{parts[0]}'
        return s[:10] if len(s) >= 10 else s

    lookup: dict = {}
    skipped = 0
    for r in rows[1:]:
        if not r[2]:           # нет даты — пропуск
            continue
        gar  = norm_gar(r[3])
        node = str(r[5] or '').strip()
        if not gar or not node:
            skipped += 1
            continue
        sys_v = str(r[6] or '').strip()[:60]
        act   = str(r[7] or '').strip()[:60]
        desc  = str(r[8] or '').strip()[:120]
        dt    = norm_dt(r[2])
        key   = gar + '||' + node
        lookup.setdefault(key, []).append(
            {'dt': dt, 'node': node, 'sys': sys_v, 'action': act, 'desc': desc}
        )

    # сортировка событий по дате
    for arr in lookup.values():
        arr.sort(key=lambda x: x['dt'])

    total_ev = sum(len(v) for v in lookup.values())
    print(f"  Ключей: {len(lookup)}, событий: {total_ev}, пропущено (нет гар/узла): {skipped}")
    return lookup

# ── Обновляем let FAIL_DATA в HTML ─────────────────────────
def update_html(lookup: dict, html_path: Path):
    if not html_path.exists():
        print(f"  ПРОПУСК: {html_path} не найден")
        return
    text = html_path.read_text(encoding='utf-8')

    # Находим const/let FAIL_DATA=... по фигурным скобкам
    for prefix in ('let FAIL_DATA=', 'const FAIL_DATA='):
        pos = text.find(prefix)
        if pos >= 0:
            break
    else:
        print(f"  ОШИБКА: FAIL_DATA не найден в {html_path.name}")
        return

    brace = text.index('{', pos)
    depth, i = 0, brace
    while i < len(text):
        if text[i] == '{': depth += 1
        elif text[i] == '}':
            depth -= 1
            if depth == 0: i += 1; break
        i += 1
    if text[i] == ';': i += 1

    new_js  = 'let FAIL_DATA=' + json.dumps(lookup, ensure_ascii=False, separators=(',', ':')) + ';'
    text    = text[:pos] + new_js + text[i:]
    html_path.write_text(text, encoding='utf-8')
    print(f"  Сохранено: {html_path.name} ({html_path.stat().st_size:,} байт)")

# ── Главная ─────────────────────────────────────────────────
def main():
    print("=" * 50)
    print("update_fail.py — обновление FAIL_DATA")
    print("=" * 50)
    try:
        xlsx = find_excel()
        data = build_fail_data(xlsx)
        update_html(data, HTML)
        if HTML2.exists():
            update_html(data, HTML2)
        print()
        print("Готово! Обновите страницу в браузере.")
    except Exception as e:
        print(f"ОШИБКА: {e}")
        import traceback; traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
    input("\nНажмите Enter для закрытия…")
